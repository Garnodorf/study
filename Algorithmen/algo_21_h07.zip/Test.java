public class Test {

	public static void main(String[] args) {
		int[] vlist = {6,10,1,5,1,4,2,3,2,6,3,4,3,5,4,5,4,2,5,6,6,1};
		Graph g = new Graph(vlist);
		System.out.println(g);
		System.out.println(g.dfs(1));
		System.out.println(g.bfs(1));
	}
}
