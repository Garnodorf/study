import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;

public class Graph {

	ArrayList<ArrayList<Integer>> vertex;
	
	/**
	 * Erstellt einen Graph mit v Knoten
	 * @param v
	 */
	public Graph(int v) {
		vertex = new ArrayList<>();
		vertex.add(null);
		for(int x = 0; x<v; ++x) {
			vertex.add(new ArrayList<>());
		}
	}
	
	/**
	 * Erstellt einen Graph aus einer Kantenliste
	 * @param list
	 */
	public Graph(int[] list) {
		this(list[0]);
		for(int x=0; x<list[1]; ++x) {
			addEdge(list[x*2+2], list[x*2+3]);
		}
	}
	
	/**
	 * Gibt die Anzahl Knoten zurueck
	 * @return
	 */
	public int getVertexCount() {
		return vertex.size()-1;
	}
	
	/**
	 * Gibt die Anzahl der kanten zurueck
	 * @return
	 */
	public int getEdgeCount() {
		int erg = 0;
		for(int x=1; x<vertex.size();++x) {
			erg += vertex.get(x).size();
		}
		return erg;
	}
	
	/**
	 * Fuegt eine neue Kante zwischen 2 Knoten hinzu
	 * @param from
	 * @param to
	 */
	public void addEdge(int from, int to) {
		if(from > 0 && from < vertex.size()) {
			vertex.get(from).add(to);
			Collections.sort(vertex.get(from));
		}else {
			throw new ArrayIndexOutOfBoundsException();
		}
	}
	
	/**
	 * Gibt einem die Kanten von Konten v nach Knoten x zurueck
	 * @param v
	 * @return
	 */
	public ArrayList<Integer> getAdjacent(int v){
		if(v > 0 && v < vertex.size()) {
			return vertex.get(v);
		}else {
			throw new ArrayIndexOutOfBoundsException();
		}
	}
	
	/**
	 * Gibt den Graph als String zurueck
	 */
	public String toString() {
		StringBuilder erg = new StringBuilder("[");
		for(int x=1; x<vertex.size(); ++x) {
			erg.append("[");
			for(int y=0; y<vertex.get(x).size(); ++y) {
				if(y!=0) {
					erg.append(",");
				}
				erg.append(vertex.get(x).get(y));
			}
			erg.append("]");
		}
		return erg.append("]").toString();
	}
	
	/**
	 * Durchlauft den Graph mit der Tiefensuche und gibt die Reihenfolge der Knoten zurueck
	 * @param start
	 * @return
	 */
	public ArrayList<Integer> dfs(int start){
		if(!(start > 0 && start < vertex.size())) {
			throw new ArrayIndexOutOfBoundsException();
		}
		ArrayList<Integer> erg = new ArrayList<>(start);
		dfs(start,new boolean[vertex.size()-1],erg);
		return erg;
	}
	
	/**
	 * Private Methode zum ermitteln der naechsten Knoten ueber die Tiefensuche
	 * @param index
	 * @param visited
	 * @param erg
	 */
	private void dfs(int index, boolean[] visited, ArrayList<Integer> erg) {
		if(visited[index-1]==true) {
			return;
		}
		visited[index-1] = true;
		erg.add(index);
		for(int x=0; x<vertex.get(index).size(); ++x) {
			dfs(vertex.get(index).get(x), visited, erg);
		}
	}
	
	/**
	 * Durchlauft den Graph mit der Breitensuche und gibt die Reihenfolge der Knoten zurueck
	 * @param start
	 * @return
	 */
	public ArrayList<Integer> bfs(int start){
		if(!(start > 0 && start < vertex.size())) {
			throw new ArrayIndexOutOfBoundsException();
		}
		ArrayList<Integer> erg = new ArrayList<>();
		erg.add(start);
		HashSet<Integer> level = new HashSet<>();
		level.add(start);
		boolean[] visited = new boolean[vertex.size()-1];
		visited[start-1] = true;
		bfs(level, visited, erg);
		return erg;
	}
	
	/**
	 * Private Methode zum ermitteln der naechsten Knoten ueber die Breitensuche
	 * @param queue
	 * @param visited
	 * @param erg
	 */
	private void bfs(HashSet<Integer> queue, boolean[] visited, ArrayList<Integer> erg) {
		HashSet<Integer> nextLevel = new HashSet<>();
		for(int index : queue) {
			for(int x=0; x<vertex.get(index).size(); ++x) {
				if(!visited[vertex.get(index).get(x)-1]) {
					nextLevel.add(vertex.get(index).get(x));
					erg.add(vertex.get(index).get(x));
					visited[vertex.get(index).get(x)-1] = true;
				}
			}
		}
		if(queue.size() == 0) {
			return;
		}else {
			bfs(nextLevel, visited, erg);
		}
	}
}
