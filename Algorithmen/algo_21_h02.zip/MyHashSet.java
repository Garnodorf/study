import java.util.ArrayList;
import java.util.Collection;

public class MyHashSet <K>{
	
	//Anzahl aller gespeicherten Elemente
	private int countElements;
	private ArrayList<Object>[] items;
	
	@SuppressWarnings("unchecked")
	public MyHashSet() {
		countElements = 0;
		items = new ArrayList[10];
		for(int x = 0; x<items.length;++x) {
			items[x] = new ArrayList<>();
		}
	}
	
	/**
	 * F�gt ein Element hinzu
	 * @param element
	 * @return true falls das Element bereits existiert, ansonsten false
	 */
	public boolean add(K element) {
		if(contains(element)) {
			return true;
		}
		int hash = hashFunction(element.hashCode());
		items[hash].add(element);
		++countElements;
		resize();
		return false;
	}
	
	/**
	 * L�scht ein Element aus der Liste
	 * @param element
	 * @return true falls das Element gel�scht wurde, sonst false
	 */
	public boolean delete(K element) {
		int hash = hashFunction(element.hashCode());
		for(int x=0; x<items[hash].size(); ++x) {
			if(items[hash].get(x).equals(element)) {
				items[hash].remove(x);
				--countElements;
				return true;
			}
		}
		return false;
	}
	
	/**
	 * �berpr�ft ob das Element bereits gespeichert wurde
	 * @param element
	 * @return true falls es bereits gespeichert wurde, sonst false
	 */
	public boolean contains(K element) {
		int hash = hashFunction(element.hashCode());
		for(int x=0; x<items[hash].size(); ++x) {
			if(items[hash].get(x).equals(element)) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Gibt alle Enthaltenen Element als eine ArrayList zur�ck
	 * @return ArrayList
	 */
	@SuppressWarnings("unchecked")
	public ArrayList<K> getElements(){
		ArrayList<K> erg =new ArrayList<K>();
		for(int x = 0;x<items.length;++x) {
			erg.addAll((Collection<? extends K>) items[x]);
		}
		return erg;
	}
	
	/**
	 * Verdoppelt die Gr��e der Map
	 */
	@SuppressWarnings("unchecked")
	private void resize() {
		if(countElements / items.length >= 2) {
			ArrayList<Object>[] tmp = new ArrayList[items.length * 2];
			for(int x = 0; x<tmp.length;++x) {
				tmp[x] = new ArrayList<>();
			}
			for(int x = 0;x<items.length;++x) {
				for(int y = 0; y < items[x].size(); ++y) {
					tmp[hashFunction(items[x].get(y).hashCode())].add(items[x].get(y));
				}
			}
			items = tmp;
		}
	}
	
	/**
	 * Berechnet aus einem HashWert einen Index
	 * @param hash
	 * @return int Index
	 */
	private int hashFunction(int hash) {
		return Math.abs(hash%items.length);
	}
}
