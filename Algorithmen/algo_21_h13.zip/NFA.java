import java.util.ArrayList;
import java.util.HashMap;

public class NFA {
	
	private HashMap<String,ArrayList<Integer>>[] map;
	private int end;
	
	/**
	 * Benoetigt eine Kantenliste um intern den Graphen des Automaten erstellen zu koennen.
	 * @param x
	 */
	@SuppressWarnings("unchecked")
	public NFA(String x) {
		String[] arr = x.split(",");
		map = new HashMap[Integer.parseInt(arr[0])];
		for(int y=0; y<map.length;++y) {
			map[y] = new HashMap<>();
		}
		end = Integer.parseInt(arr[1]);
		
		for(int y=2;y<arr.length;y+=3) {
			if(!map[Integer.parseInt(arr[y])].containsKey(arr[y+2])) {
				map[Integer.parseInt(arr[y])].put(arr[y+2], new ArrayList<>());
			}
			map[Integer.parseInt(arr[y])].get(arr[y+2]).add(Integer.parseInt(arr[y+1]));
		}
	}
	
	/**
	 * Test ob der String zu vorher angegebenen Graphen passt.
	 * @param s
	 * @return
	 */
	public boolean testString(String s) {
		boolean[] erg = new boolean[1];
		test(erg, s, 1, 0);
		return erg[0];
	}
	
	/**
	 * Rekursive Methode um zu testen, ob der Ausdruck zum Graphen passt.
	 * @param bool
	 * @param str
	 * @param node
	 * @param pos
	 */
	private void test(boolean[] bool, String str, int node, int pos) {
		if(node == end && pos == str.length()) {
			bool[0] = true;
			return;
		}else if(node == end || pos == str.length()) {
			return;
		}
		ArrayList<Integer> nextNodes = map[node].get(Character.toString(str.charAt(pos)));
		for(int x=0;x<nextNodes.size();++x) {
			test(bool, str, nextNodes.get(x), pos+1);
		}
	}
	
	/**
	 * Test main zum Testen
	 * @param args
	 */
	public static void main(String[] args) {
		String str = "3,3,1,2,a,1,3,a,2,2,a,2,2,b,2,3,a";
		NFA test = new NFA(str);
		System.out.println(test.testString("abba"));
		System.out.println(test.testString("a"));
		System.out.println(test.testString("ab"));
	}
}
