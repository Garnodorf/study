public class MTS {

	/**
	 * Berechnet die kosten eines minimalen Spannbaums welcher, durch die uebergebene Matrix definiert wird.
	 * Gibt dabei die wege und wurzel in der Konsole aus.
	 * @param edges
	 * @return kosten des minimalen Spannbaums
	 */
	public static int getMTS(int[][] edges){
		boolean[] connected = new boolean[edges.length];
		int costs = 0;
		int start = 0;
		int stop = 0;
		int cost;
		connected[0] = true;
		System.out.println("waehle 1 als Wurzel");
		for(int x=0;x<edges.length-1;++x){
			cost = -1;
			for(int y=0;y<connected.length;++y){
				if(connected[y]){
					for(int z=0;z<edges[y].length;++z){
						if((cost == -1 || cost > edges[y][z]) && !connected[z] && edges[y][z] != 0){
							cost = edges[y][z];
							start = y;
							stop = z;
						}
					}
				}	
			}
			System.out.println("Kante hinzugefuegt von " + (start+1) + " zu " + (stop+1));
			connected[stop] = true;
			costs+=edges[start][stop];
		}
		
		
		return costs;
	}
	
	/**
	 * Test
	 * @param args
	 */
	public static void main(String[] args) {
		int[][] adjazenzmatrix = {  { 0, 3, 0, 2, 0,0},
									{ 3, 0, 2, 0, 3,0},
									{ 0, 2, 0, 1, 6,0},
									{ 2, 0, 1, 0, 0,0},
									{ 0, 3, 6, 0, 0,5},
									{ 0, 0, 0, 0, 5,0}
		};
		System.out.println("resultierende kosten: " + getMTS(adjazenzmatrix));
	}
}
