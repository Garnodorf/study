public class Test {
	
	public static void main(String[] args) {
		System.out.println(Brackets.isValid("(([[]]))"));										//true
		System.out.println(Brackets.isValid("([)]"));											//false
		System.out.println(Brackets.isValid("([]])"));											//false
		System.out.println(Brackets.isValid("(()))"));											//false
		System.out.println(Brackets.isValid("(()"));											//false
		System.out.println(Brackets.isValid("({[])}"));											//false
		System.out.println(Brackets.isValid("Die Methode ist Static weil es SINN macht!"));		//true
	}
}
