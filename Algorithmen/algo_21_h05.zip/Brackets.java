public class Brackets {
	//Die Methode ist static, da diese keine Attribute inerhalb der Klasse verwendet und es unnoetig w�re, daf�r ein Objekt zu erstellen.

	/**
	 * Testet ob jede Klammer von einer Klammer der gleichen art geschlossen wird.
	 * @param s 
	 * @return true wenn alle Klammern geschlossen werden, sonst false
	 */
	public static boolean isValid(String s) {
		MyDeque stack = new MyDeque();
		char val;
		String lastVal;
		for(int x=0;x<s.length();++x) {
			val = s.charAt(x);
			if(val == '(' || val == '[' || val == '{') {
				stack.addLast(Character.toString(val));
			}else if(val == ')' || val == ']' || val == '}') {
				lastVal = stack.removeLast();
				if(lastVal == null) {
					return false;
				}
				if(lastVal.equals("(")) {
					if(val != ')') {
						return false;
					}
				}else if(lastVal.equals("[")) {
					if(val != ']') {
						return false;
					}
				}else if(lastVal.equals("{")) {
					if(val != '}') {
						return false;
					}
				}
			}
		}
		if(stack.removeLast() != null) {
			return false;
		}
		return true;
	}
}
