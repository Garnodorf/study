public class MyDeque {

	private class DequeValue{
		public String value;
		public DequeValue left;
		public DequeValue right;
		
		public DequeValue(String value, DequeValue left, DequeValue right) {
			this.value = value;
			this.left = left;
			this.right = right;
		}
	}
	
	private DequeValue first;
	private DequeValue last;
	
	/**
	 * Fuegt ein Element an der ersten Position hinzu
	 * @param value
	 */
	public void addFirst(String value) {
		if(first == null) {
			first = new DequeValue(value, null, null);
			last = first;
		}else {
			first.left = new DequeValue(value, null, first);
			first = first.left;
		}
	}
	
	/**
	 * Fuegt ein Element an der letzten Position hinzu
	 * @param value
	 */
	public void addLast(String value) {
		if(last == null) {
			last = new DequeValue(value, null, null);
			first = last;
		}else {
			last.right = new DequeValue(value, last, null);
			last = last.right;
		}
	}
	
	/**
	 * Loescht das erste Element unnd gibt dieses zurueck. Gibt null zurueck wenn kein Element enthalten ist.
	 * @return
	 */
	public String removeFirst() {
		if(first == null) {
			return null;
		}
		String erg = first.value;
		first = first.right;
		return erg;
	}
	
	/**
	 * Loescht das letzte Element unnd gibt dieses zurueck. Gibt null zurueck wenn kein Element enthalten ist.
	 * @return
	 */
	public String removeLast() {
		if(last == null) {
			return null;
		}
		String erg = last.value;
		last = last.left;
		return erg;
	}
}
