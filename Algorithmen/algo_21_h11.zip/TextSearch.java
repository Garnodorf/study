import java.util.ArrayList;
import java.util.regex.PatternSyntaxException;

public class TextSearch {

	/**
	 * Testet ob ein bestimmtes Wort in einem Text enthalten ist 
	 * @param text
	 * @param pattern
	 * @return
	 */
	public static ArrayList<Integer> textSearch(String text, String pattern){
		int testPattern = testPattern(pattern);
		if(testPattern != -1) {
			throw new PatternSyntaxException("invalid amount of brackets", pattern, testPattern);
		}
		ArrayList<Integer> erg = new ArrayList<>();
		boolean goodPattern;
		for(int x=0; x<text.length();++x) {
			goodPattern = true;
			for(int y=0, ppos = 0;y+ppos<pattern.length();++y) {
				if(x+y >= text.length()) {
					goodPattern = false;
					break;
				}
				if(pattern.charAt(y+ppos) == '.') {
					continue;
				}else if(pattern.charAt(y+ppos) == '[') {
					//System.out.println(textSearch("abcabcdababdc.", "b[cd]")); 	//1,4,10
					++ppos;
					goodPattern = false;
					while(pattern.charAt(y+ppos) != ']') {
						if(goodPattern == true) {
							++ppos;
							continue;
						}else if(pattern.charAt(y+ppos) == text.charAt(x+y)) {
							goodPattern = true;
						}
						++ppos;
					}
				}else if(pattern.charAt(y+ppos) == '\\') {
					++ppos;
					if(pattern.charAt(y+ppos) != text.charAt(x+y)) {
						goodPattern = false;
					}
				}else {
					if(pattern.charAt(y+ppos) != text.charAt(x+y)) {
						goodPattern = false;
						break;
					}
				}
			}
			if(goodPattern) {
				erg.add(x);
			}
		}
		return erg;
	}
	
	/**
	 * Testet im Pattern ob jede offene Klammer auch wieder geschlossen wird
	 * @param pattern
	 * @return -1 falls in Ordnung sonst Position der ungeschlossenen Klammer im Pattern
	 */
	private static int testPattern(String pattern) {
		int pos=0;
		boolean patternOpened=false;
		for(int x=0;x<pattern.length();++x) {
			if(pattern.charAt(x) == '[') {
				if(x == 0 || pattern.charAt(x-1) != '\\'){
						patternOpened = true;
						pos = x;
				}
			}else if(pattern.charAt(x) == ']') {
				if(patternOpened) {
					patternOpened = false;
				}
			}
		}
		if(patternOpened) {
			return pos;
		}
		return -1;
	}
	
	/**
	 * Testet
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println(textSearch("abcabcdababdc.", "ab")); 	//0, 3, 7, 9
		System.out.println(textSearch("abcabcdababdc.", "c.")); 	//2, 5, 12
		System.out.println(textSearch("abcabcdababdc.", "c\\.")); 	//12
		System.out.println(textSearch("abcabcdababdc.", "b[cd]")); 	//1,4,10
		System.out.println(textSearch("abcabcdababdc.", "a....c")); //0,7
		System.out.println(textSearch("a[aababa][ab]a", "a[ab]a")); //3,5
		System.out.println(textSearch("a[aababa][ab]a", "a.\\[a")); //7
	}
}
