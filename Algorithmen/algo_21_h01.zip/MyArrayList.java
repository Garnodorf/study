package de.lordgarno;

public class MyArrayList<T> {
	
	private Object[] array;
	private int index;
	
	public MyArrayList() {
		clear();
	}
	
	private void increase() {
		Object[] tmp = new Object[index*2];
		for(int x=0;x<array.length;++x) {
			tmp[x] = array[x];
		}
		array = tmp;
	}
	
	public void addFirst(T element) {
		if(index == array.length) {
			increase();
		}
		Object[] tmp = new Object[array.length];
		tmp[0] = element;
		for(int x=0;x<index;++x) {
			tmp[x+1] = array[x];
		}
		array = tmp;
		++index;
	}
	
	public void addLast(T element) {
		if(index == array.length) {
			increase();
		}
		array[index++] = element; 
	}
	
	public T get(int id) {
		if(id < 0 || id >= index) {
			throw new IndexOutOfBoundsException();
		}
		return (T)array[id];
	}
	
	public void clear() {
		array = new Object[10];
		index = 0;
	}
	
	public int size() {
		return index;
	}
}
