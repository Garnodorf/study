import java.util.ArrayList;

public class GewichteMessDing {

	/**
	 * Berechnet ob das gewicht von produkt durch gewichte dargestellt werden kann und gibt moegliche Ergebnisse auf dem Bildschirm aus.
	 * @param gewichte
	 * @param produkt
	 */
	static void wiegen(double[] gewichte, double produkt) {
		wiegen(gewichte, produkt, gewichte.length, new ArrayList<>());
	}
	
	/**
	 * Berechnet rekursiv alle moeglichkeiten um das gewuenschte Gewischt zu erreichen
	 * @param gewichte
	 * @param produkt
	 * @param tiefe
	 * @param erg
	 */
	static void wiegen(double[] gewichte, double produkt, int tiefe, ArrayList<Double> erg) {
		if(tiefe == 0) {
			double sum = 0;
			for(int x=0;x<erg.size();++x) {
				sum += erg.get(x);
			}
			if(Math.abs(sum) == produkt) {
				System.out.println(erg.toString());
			}
			return;
		}
		erg.add(gewichte[tiefe-1]);
		wiegen(gewichte, produkt, tiefe-1, erg);
		erg.remove(erg.size()-1);
		erg.add(-gewichte[tiefe-1]);
		wiegen(gewichte, produkt, tiefe-1, erg);
		erg.remove(erg.size()-1);
		wiegen(gewichte, produkt, tiefe-1, erg);
	}
	
	/**
	 * Test funktion zum Testen
	 * @param args
	 */
	public static void main(String[] args) {
		double[] gewichte = {1,3,8,20};
		double produkt = 16;
		
		wiegen(gewichte, produkt);
	}
}
