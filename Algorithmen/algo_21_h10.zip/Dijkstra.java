package nr10;

public class Dijkstra {

	/**
	 * Gibt einem die Ausgabe des Dijkstra Algorithmus
	 * @param kanten
	 */
	public static void printDijkstra(int[] kanten) {
		printHead(kanten[0]);
		int currentPos = 1;
		int lastPos = 0;
		boolean[] used = new boolean[kanten[0]];
		int[][] left = new int[kanten[0]][kanten[0]-1];
		int[][] right = new int[kanten[0]][kanten[0]-1];
		
		used[0] = true;
		for(int x=0;x<kanten[0];++x) {
			if(currentPos != 1) {
				for(int z=0;z<left[currentPos-1].length; ++z) {
					left[currentPos-1][z] = left[lastPos-1][z];
					right[currentPos-1][z] = right[lastPos-1][z];
				}
			}
			for(int y=1;y<kanten.length;y+=3) {
				if(kanten[y]==currentPos) {
					if(kanten[y+1] == 1) {
						continue;
					}
					else if(currentPos == 1) {
						left[currentPos-1][kanten[y+1]-2] = kanten[y+2];
						right[currentPos-1][kanten[y+1]-2] = currentPos;
					}else if(left[currentPos-1][kanten[y+1]-2] == 0){
						left[currentPos-1][kanten[y+1]-2] = kanten[y+2]+left[currentPos-1][currentPos-2];
						right[currentPos-1][kanten[y+1]-2] = currentPos;
					}else if(left[currentPos-1][currentPos-2]+kanten[y+2] < left[currentPos-1][kanten[y+1]-2]) {
						left[currentPos-1][kanten[y+1]-2] = kanten[y+2]+left[currentPos-1][currentPos-2];
						right[currentPos-1][kanten[y+1]-2] = currentPos;
					}
				}
			}
			printLine(currentPos-1, right, left);
			
			lastPos = currentPos;
			currentPos = calcLowestElement(left[currentPos-1], used)+2;
		}
	}
	
	/**
	 * Berechnet das naechst kleiner Element(Reihe) welche noch nicht verwendet wurde
	 * @param row aktuelle Reihe
	 * @param used 
	 * @return
	 */
	private static int calcLowestElement(int[] row, boolean[] used) {
		int minIndex = 0;
		boolean firstSet = false;
		for(int x=0;x<row.length;++x) {
			if(!firstSet) {
				if(!used[x+1]) {
					minIndex = x;
					firstSet = true;
				}
			}else if(row[x] > 0  && row[x] < row[minIndex] && !used[x+1]) {
				minIndex = x;
			}
		}
		used[minIndex+1] = true;
		return minIndex;
	}
	
	/**
	 * Erstellt eine Zeile der Ausgabe
	 * @param pos
	 * @param right
	 * @param left
	 */
	private static void printLine(int pos, int[][] right, int[][] left) {
		if(pos+1<10)
			System.out.print(" "+(pos+1)+"|");
		else
			System.out.print((pos+1)+"|");
		for(int x=0;x<left[pos].length;++x) {
			if(left[pos][x]<=0)
				System.out.print(" --");
			else if(left[pos][x]<10)
				System.out.print("  "+left[pos][x]);
			else
				System.out.print(" "+left[pos][x]);
		}
		System.out.print("|");
		for(int x=0;x<right[pos].length;++x) {
			if(right[pos][x]<=0)
				System.out.print(" --");
			else if(right[pos][x]<10)
				System.out.print("  "+right[pos][x]);
			else
				System.out.print(" "+right[pos][x]+"|");
		}
		System.out.print("|\n");
	}

	/**
	 * Erstellt die ersten 2 Zeilen der Ausgabe
	 * @param vertex Anzahl der Knoten
	 */
	private static void printHead(int vertex) {
		System.out.print("vi|");
		for(int x=2; x<=vertex; ++x) {
			System.out.print(" ");
			if(x<10)
				System.out.print(" "+x);
			else
				System.out.print(x);
		}
		System.out.print("|");
		for(int x=2; x<=vertex; ++x) {
			System.out.print(" ");
			if(x<10)
				System.out.print(" "+x);
			else
				System.out.print(x);
		}
		System.out.print("|\n");
		for(int x=0;x<(vertex-1)*6+5 ; ++x) {
			System.out.print("-");
		}
		System.out.println("");
	}
	
	/**
	 * Test main
	 * @param args
	 */
	public static void main(String[] args) {
		int[] test1 = {4,1,2,2,1,4,5,2,4,1,2,3,4,3,1,1,4,3,1};
		int[] test2 = {10,1,2,30,1,3,10,2,5,15,2,8,55,3,4,5,3,9,35,4,2,10,4,5,45,4,6,10,5,3,20,5,7,15,5,9,25,6,7,5,7,10,20,8,10,15,9,8,10,9,10,30};
		printDijkstra(test2);
	}
}
