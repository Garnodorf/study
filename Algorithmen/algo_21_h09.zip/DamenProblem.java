import java.util.ArrayList;

public class DamenProblem {
	
	static int value;
	
	/**
	 * Gibt einem alle moeglichen Positionen fuer ein nxn Feld aus
	 * @param n
	 */
	public void damenProblem(int n){
		value=0;
		damenProblem(n, new ArrayList<Integer>());
	}
	
	/**
	 * Berechnet alle Positionen f�r ein nxn Feld
	 * @param n
	 * @param arrayList
	 */
	private void damenProblem(int n, ArrayList<Integer> arrayList){
		if(arrayList.size() == n){
			System.out.println(arrayList+ " L�sung: " + ++value);
			return;
		}
		for(int x=0; x<n; ++x){
			if(!testPosition(arrayList, x+1, n)){
				continue;
			}
			arrayList.add(x+1);
			damenProblem(n, arrayList);
			arrayList.remove(arrayList.size()-1);
		}
	}
	
	/**
	 * Testet ob die position von keiner anderen Dame getroffen werden kann.
	 * @param field
	 * @param pos
	 * @param n
	 * @return true wenn die Position sicher ist, sonst false
	 */
	private boolean testPosition(ArrayList<Integer> field, int pos, int n){
		if(field.contains(pos)){
			return false;
		}
		int row = field.size()-1;
		int posTop = pos-1;
		int posBottom = pos+1;
		for(;row>=0; --row, --posTop, ++posBottom){
			if(posTop > 0 && field.get(row) == posTop){
				return false;
			}if(posBottom <= n && field.get(row) == posBottom){
				return false;
			}
		}
		return true;
	}
	
	/**
	 * Test main zum Testen
	 * @param args
	 */
	public static void main(String[] args) {
		DamenProblem test = new DamenProblem();
		test.damenProblem(14);
	}
}
