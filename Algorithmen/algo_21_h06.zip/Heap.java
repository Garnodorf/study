import java.util.ArrayList;
import java.util.Collections;

public class Heap {
	
	ArrayList<Integer> heap;
	
	/**
	 * Konstruktor
	 */
	public Heap() {
		heap = new ArrayList<>();
		heap.add(null);
	}
	
	/**
	 * Gibt zur�ck ob der Heap Leer ist
	 * @return true falls leer, sonst false
	 */
	public boolean isEmpty() {
		if(heap.size() == 1) {
			return true;
		}
		return false;
	}
	
	/**
	 * Fuegt dem Heap einen Wert hinzu
	 * @param i
	 * @throws ArithmeticException falls Element bereit enthalten ist
	 */
	public void add(int i) {
		if(heap.contains(i)) {
			throw new ArithmeticException();
		}
		heap.add(i);
		upHeap();
	}
	
	/**
	 * Gleicht den Heap wieder aus, falls das hinzugef�gte Element groesser als seine Eltern ist
	 */
	private void upHeap() {
		for(int x=heap.size()-1;x>1;) {
			if(heap.get(x) > heap.get(x/2)) {
				Collections.swap(heap, x, x/2);
				x/=2;
			}else {
				break;
			}
		}
	}
	
	/**
	 * Gibt den groessten Wert aus und entfernt ihn
	 * @return int groesster Wert
	 * @throws ArithmeticException falls kein Wert enthalten ist
	 */
	public int getMax() {
		if(heap.size() == 1) {
			throw new ArithmeticException();
		}
		int erg = heap.get(1);
		downHeap();
		return erg;
	}
	
	/**
	 * Gleicht den Heap aus, falls das letzte Element kleiner als seine Kinder ist
	 */
	private void downHeap() {
		int size = heap.size();
		Collections.swap(heap, 1, --size);
		heap.remove(size);
		int left;
		int right;
		for(int x=1;x<size;) {
			if(x*2 < size) {
				left = heap.get(x*2);
			}else {
				left = -1;
			}
			if(x*2+1 < size) {
				right = heap.get(x*2+1);
			}else {
				right = -1;
			}
			if(left > right) {
				if(left > heap.get(x)) {
					Collections.swap(heap, x, x*2);
					x = x*2;
				}else {
					break;
				}
			}else {
				if(right > heap.get(x)) {
					Collections.swap(heap, x, x*2+1);
					x = x*2+1;
				}else {
					break;
				}
			}
		}
	}
	
	/**
	 * Wandelt den Heap in einen String um
	 */
	public String toString() {
		StringBuilder erg = new StringBuilder("[");
		if(heap.size()>1) {
			erg.append(heap.get(1));
		}
		for(int x=2;x<heap.size();++x) {
			erg.append(", " + heap.get(x));
		}
		erg.append("]");
		return erg.toString();
	}
}
