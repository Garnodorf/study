public class Test {

	/**
	 * Sind halt Tests
	 * @param args
	 */
	public static void main(String[] args) {
		Heap test = new Heap();
		System.out.println(test);
		test.add(1);
		System.out.println(test);
		test.add(6);
		System.out.println(test);
		test.add(8);
		System.out.println(test);
		test.add(18);
		System.out.println(test);
		test.add(23);
		System.out.println(test);
		test.add(5);
		System.out.println(test);
		test.add(17);
		System.out.println(test);
		test.add(20);
		System.out.println(test);
		test.add(26);
		System.out.println(test);
		test.add(21);
		System.out.println(test);
		test.add(9);
		System.out.println(test);
		System.out.println(test.getMax());
		System.out.println(test);
		System.out.println(test.getMax());
		System.out.println(test);
		System.out.println(test.getMax());
		System.out.println(test);
		System.out.println(test.getMax());
		System.out.println(test);
		System.out.println(test.getMax());
		System.out.println(test);
		System.out.println(test.getMax());
		System.out.println(test);
		System.out.println(test.getMax());
		System.out.println(test);
		System.out.println(test.getMax());
		System.out.println(test);
		System.out.println(test.getMax());
		System.out.println(test);
		System.out.println(test.getMax());
		System.out.println(test);
		System.out.println(test.getMax());
		System.out.println(test);
	}
}
