package de.lordgarno;

public class GeradeR2 extends AbstrakteEbene implements Hyperebene{

	@Override
	public VektorRn getNormalenvektor() {
		double[] norm=new double[2];
		double[] tmp=getRichtungsvektoren()[0].getElements();
		norm[0]=tmp[1];
		norm[1]=-tmp[0];
		return new VektorRn(norm);
	}

	@Override
	public String getNormalform() {
		double[] norm = getNormalenvektor().getElements();
		double[] point = getOrtsvektor().getVektorRn().getElements();
		double rs = norm[0]*point[0]+norm[1]*point[1];
		StringBuilder erg = new StringBuilder(norm[0]+"a");
		if(norm[1]>=0){
			erg.append("+");
		}
		erg.append(norm[1]+"b="+rs);
		return erg.toString();
	}

	public GeradeR2(Punkt p1, Punkt p2){
		VektorRn v1 = p1.getVektorRn();
		VektorRn v2 = p2.getVektorRn();
		VektorRn erg = v2.add(v1.mult(-1));
		init(p1, erg);
	}
	
	public GeradeR2(VektorRn n, Punkt p){
		init(p, n);
	}
	
	private void init(Punkt p, VektorRn rv){
		int dim = p.getVektorRn().getElements().length;
		VektorRn[] r = new VektorRn[1];
		if (rv.getElements().length != dim) {
			throw new RuntimeException("Die Dimensionen stimmen nicht �berein"); 
		}
		r[0]=rv;
		this.p = p;
		this.r = r;
	}
}
