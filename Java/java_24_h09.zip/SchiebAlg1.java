package de.lordgarno;

import java.util.Random;

public class SchiebAlg1 implements Loesungsalgorithmus{

	@Override
	/**
	 * Verschiebt solange zufaellig die Zahlen, bis die 1 an seinem Platz steht.
	 */
	public void loese(Schiebepuzzle puzzle) {
		Random r=new Random();
		int value=0;
		for(;puzzle.getPlate()[0][0]!=1;){
			for(;true;){
				value=r.nextInt(16);
				if(puzzle.istVerschiebbar(value)){
					break;
				}
			}
			puzzle.schiebe(value);
		}
	}

}
