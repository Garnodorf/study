package de.lordgarno;

public interface Loesungsalgorithmus {

	/**
	 * loest ein Schiebepuzzle
	 * @param puzzle Schiebepuzzle
	 */
	public void loese(Schiebepuzzle puzzle);
}
