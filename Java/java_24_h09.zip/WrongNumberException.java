package de.lordgarno;

public class WrongNumberException extends RuntimeException{
	
	private static final long serialVersionUID = 1L;

	/**
	 * Ruft den konstruktor der Vaterklasee auf und uebergibt einen String
	 * @param string
	 */
	public WrongNumberException(String string) {
		super(string);
	}
	
}
