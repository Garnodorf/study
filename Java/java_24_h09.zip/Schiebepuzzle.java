package de.lordgarno;

import java.util.Random;

public class Schiebepuzzle {

	private int plate[][];
	
	/**
	 * Konstruktor initialisiert ein 2 Dimensionales int Array mit den Werten 0-15.
	 * 0 bezeichnet das leere Feld 
	 */
	public Schiebepuzzle(){
		plate=new int[4][4];
		int value=1;
		for(int x=0;x<4;++x){
			for(int y=0;y<4;++y){
				if(x==3&&y==3){
					plate[3][3]=0;
				}else{
					plate[x][y]=value;
					++value;
				}
			}
		}
	}
	
	/**
	 * Gibt einen String zurueck, indem das Spielfeld zu sehen ist. Mit Zeilenumbrueche.
	 */
	public String toString(){
		StringBuilder erg=new StringBuilder();
		for(int x=0;x<4;++x){
			erg.append("|");
			for(int y=0;y<4;y++){
				if(plate[x][y]==0){
					erg.append("  |");
					continue;
				}else if(plate[x][y]<10){
					erg.append(" ");
				}
				erg.append(plate[x][y]+"|");
			}
			erg.append("\n-------------\n");
		}
		return erg.toString();
	}
	
	/**
	 * Verschiebt eine Zahl auf das leere Feld.
	 * @param i int von 1-15
	 * @throws WrongNumberException wenn eine Zahl außerhalb des Zahlenbereiches 1-15 uebergeben wird.
	 * @throws WrongMoveException wenn die Zahl nicht auf das leere Feld gesetzt werden kann.
	 */
	public void schiebe(int i){
		if(i<1||i>15){
			throw new WrongNumberException("value must be between 1 and 15 inclusive");
		}
		if(!istVerschiebbar(i)){
			throw new WrongMoveException("can not move this plate");
		}
		swap(i);
	}
	
	/**
	 * Testet ob die Zahl auf das leere Feld verschoben werden kann.
	 * @param i Zahl die verschoben werden soll
	 * @return true wenn die Zahl auf das leere Feld verschoben werden kann. 
	 * @return false wenn die Zahl nicht verschoben werden kann.
	 */
	public boolean istVerschiebbar(int i){
		int posX=-1;
		int posY=-1;
		for(int x=0;x<4;++x){
			for(int y=0;y<4;++y){
				if(plate[x][y]==i){
					posX=x;
					posY=y;
				}
			}
		}
		if(posX==-1&&posY==-1){
			return false;
		}
		//north
		if(posX-1>=0){
			if(plate[posX-1][posY]==0){
				return true;
			}
		}
		//east
		if(posY+1<=3){
			if(plate[posX][posY+1]==0){
				return true;
			}
		}
		//south
		if(posX+1<=3){
			if(plate[posX+1][posY]==0){
				return true;
			}
		}
		//west
		if(posY-1>=0){
			if(plate[posX][posY-1]==0){
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Tauscht das leere Feld (0) mit der angegebenen Zahl.
	 * @param i Zahl die vertauscht werden soll
	 * @throws WrongMoveException wenn die zahlen nicht verschoben werden duerfen.
	 */
	private void swap(int i){
		if(!istVerschiebbar(i)){
			throw new WrongMoveException("can not move this plate");
		}
		int[][] tmp=new int[2][2];
		for(int x=0;x<4;++x){
			for(int y=0;y<4;++y){
				if(plate[x][y]==i){
					tmp[0][0]=x;
					tmp[0][1]=y;
				}
			}
		}
		for(int x=0;x<4;++x){
			for(int y=0;y<4;++y){
				if(plate[x][y]==0){
					tmp[1][0]=x;
					tmp[1][1]=y;
				}
			}
		}
		plate[tmp[0][0]][tmp[0][1]]=0;
		plate[tmp[1][0]][tmp[1][1]]=i;
	}
	
	/**
	 * Mischt die Zahlen, mit gültigen Zuegen.
	 */
	public void mische(){
		Random r=new Random();
		int value=0;
		for(int x=0;x<10000;++x){
			for(;true;){
				value=r.nextInt(16);
				if(istVerschiebbar(value)){
					break;
				}
			}
			swap(value);
		}
	}
	
	/**
	 * Gibt ein klon des Zweidimensionalen int Array Attributs zurueck
	 * @return int[][] plate
	 */
	public int[][] getPlate(){
		int[][] erg =new int[4][4];
		for(int x=0;x<4;++x){
			for(int y=0;y<4;++y){
				erg[x][y]=plate[x][y];
			}
		}
		return erg;
	}
}
