package de.lordgarno;

public class WrongMoveException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	/**
	 * Ruft den konstruktor der Vaterklasee auf und uebergibt einen String
	 * @param string
	 */
	public WrongMoveException(String string){
		super(string);
	}
}
