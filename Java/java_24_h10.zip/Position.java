package de.lordgarno;

public class Position {

	private int x;
	private int y;
	
	/**
	 * Konstruktor: Setzt die Position auf (x,y) 
	 * @param x int x-koordinate
	 * @param y int y-koordinate
	 */
	public Position(int x, int y){
		this.x=x;
		this.y=y;
	}
	
	/**
	 * Gibt die x-Koordinate zurueck
	 * @return int x
	 */
	public int getX(){
		return this.x;
	}
	
	/**
	 * Gibt die y-Koordinate zurueck
	 * @return int y
	 */
	public int getY(){
		return this.y;
	}
	
	/**
	 * Ueberprueft ob dieses und ein weiteres Positions Objekt identisch sind.
	 * @param p Position zweites Positions Objekt
	 * @return true wenn beide Objekte identisch sind
	 * @return false wenn beide Objekte nicht identisch sind
	 */
	public boolean equals(Position p){
		if(this.getX()==p.getX()&&this.getY()==p.getY()){
			return true;
		}
		return false;
	}
	
	/**
	 * Ueberprueft ob die Position innerhalb des Schachfeldes liegt
	 * @return true wenn die Position innerhalb des Schachfeldes liegt
	 * @return false wenn die Position nicht innerhalb des Schachfeldes liegt
	 */
	public boolean isValid(){
		if(this.getX()>=1&&this.getX()<=8 && this.getY()>=1&&this.getY()<=8){
			return true;
		}
		return false;
	}
	
	/**
	 * Wandelt das Objekt in ein String der Form "(x/y)" um
	 * @return String 
	 */
	public String toString(){
		StringBuilder erg=new StringBuilder("("+this.getX()+"/"+this.getY()+")");
		return erg.toString();
	}
}
