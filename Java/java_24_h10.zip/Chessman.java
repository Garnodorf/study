package de.lordgarno;

import java.util.ArrayList;

public abstract class Chessman {

	protected Position pos;
	
	/**
	 * Konstruiert die Schachfigur und legt dessen Position fest
	 * @param pos Position 
	 * @throws RuntimeException wenn die Position nicht erlaubt ist
	 */
	public Chessman(Position pos){
		if(!pos.isValid()){
			throw new RuntimeException("invalid position");
		}
		this.pos=pos;
	}
	
	/**
	 * Gibt die position der Schachfigur zurueck
	 * @return Position
	 */
	public Position getPosition(){
		return this.pos;
	}
	
	/**
	 * Bewegt die Schachfigur zur angegebenen Stelle
	 * @param pos Position
	 * @throws RuntimeException wenn die Position nicht erlaubt ist
	 */
	public void moveTo(Position pos){
		if(!canMoveTo(pos)){
			throw new RuntimeException("invalid position");
		}
		this.pos=pos;
	}
	
	/**
	 * Gibt einen eine ArrayListe mit allen Moeglichen Zuegen der Schachfigur zurueck.
	 * @return ArrayList<Position>
	 */
	public abstract ArrayList<Position> getMoveList();
	
	/**
	 * Ueberpueft ob die Schachfigur sich auf die angegebene Position bewegen kann
	 * @param pos Position
	 * @return true wenn die Position erreicht werden kann
	 * @return false wenn die Position nicht erreicht werden kann
	 */
	public boolean canMoveTo(Position pos){
		ArrayList<Position> arr = getMoveList();
		for(int x=0;x<arr.size();++x){
			if(arr.get(x).equals(pos)){
				return true;
			}
		}
		return false;
	}
	
	//Kann man bei den java Doc Kommentaren mehrmals @return verwenden?
}
