package de.lordgarno;

import java.util.ArrayList;

public class Knight extends Chessman{

	public Knight(Position pos) {
		super(pos);
	}

	@Override
	/**
	 * Erstellt alle Moeglichen Positionen für einen Springer und Ueberprueft diese auf gueltigkeit
	 * @return ArrayList<Position> Alle gueltigen Positionen
	 */
	public ArrayList<Position> getMoveList() {
		ArrayList<Position> erg = new ArrayList<>();
		Position[] p=new Position[8];
		p[0] = new Position(pos.getX()-2,pos.getY()-1);
		p[1] = new Position(pos.getX()-2,pos.getY()+1);
		p[2] = new Position(pos.getX()+2,pos.getY()-1);
		p[3] = new Position(pos.getX()+2,pos.getY()+1);
		p[4] = new Position(pos.getX()-1,pos.getY()-2);
		p[5] = new Position(pos.getX()+1,pos.getY()-2);
		p[6] = new Position(pos.getX()-1,pos.getY()+2);
		p[7] = new Position(pos.getX()+1,pos.getY()+2);
		for(int x=0;x<8;++x){
			if(p[x].isValid()){
				erg.add(p[x]);
			}
		}
		return erg;
	}

	/**
	 * Wandelt das Objekt in ein String der Form "Springer: (x/y)" um
	 * @return String 
	 */
	public String toString(){
		StringBuilder erg = new StringBuilder("Springer: "+pos.toString());
		return erg.toString();
	}
}
