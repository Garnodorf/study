package de.lordgarno;

import java.util.ArrayList;

public class Rook extends Chessman{

	public Rook(Position pos) {
		super(pos);
	}

	@Override
	/**
	 * Erstellt alle Moeglichen Positionen für einen Turm und Ueberprueft diese auf gueltigkeit
	 * @return ArrayList<Position> Alle gueltigen Positionen
	 */
	public ArrayList<Position> getMoveList() {
		ArrayList<Position> erg = new ArrayList<>();
		int posX;
		int posY;
		Position tmp;
		//X-Achse
		for(int x=0;x<2;++x){
			posX=pos.getX();
			posY=pos.getY();
			for(;true;){
				if(x%2==0){
					tmp = new Position(++posX,posY);
					if(!tmp.isValid()){
						break;
					}
					erg.add(tmp);
				}else{
					tmp = new Position(--posX,posY);
					if(!tmp.isValid()){
						break;
					}
					erg.add(tmp);
				}
			}
		}
		//Y-Achse
		for(int x=0;x<2;++x){
			posX=pos.getX();
			posY=pos.getY();
			for(;true;){
				if(x%2==0){
					tmp = new Position(posX,++posY);
					if(!tmp.isValid()){
						break;
					}
					erg.add(tmp);
				}else{
					tmp = new Position(posX,--posY);
					if(!tmp.isValid()){
						break;
					}
					erg.add(tmp);
				}
			}
		}
		return erg;
	}
	
	/**
	 * Wandelt das Objekt in ein String der Form "Turm: (x/y)" um
	 * @return String 
	 */
	public String toString(){
		StringBuilder erg = new StringBuilder("Turm: "+pos.toString());
		return erg.toString();
	}

}
