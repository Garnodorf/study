package de.lordgarno;

public class MyArrayList {
	private int[] arr; // = new int[10] wird im Standard Konstruktor initialisiert
	private int size; // = 0
	
	/**
	 * Standard Konstruktor initialisiert die Attribute 
	 */
	public MyArrayList(){
		this.arr = new int[10];
		this.size = 0;
	}
	
	/**
	 * Fuegt ein Element der Liste hinzu
	 * @param i Element welches hinzugefügt wird
	 */
	public void add(int i){
		arr[size]=i;
		size++;
		resize();
	}
	
	/**
	 * Gibt das Element an der jeweiligen stelle zurueck
	 * @param pos position des Elements
	 * @return Element an der Stelle pos
	 * @throws ArrayindexOutOfBoundException wenn pos nicht zwischen 0 und size liegt
	 */
	public int get(int pos){
		if(pos<0 || pos >=size){
			throw new ArrayIndexOutOfBoundsException("pos liegt nicht zwischen 0 und size");
		}
		return arr[pos];
	}
	
	/**
	 * Gibt das Objekt als String zurück
	 */
	public String toString(){
		String erg="";
		if(this.size==0){
			return "[]";
		}
		erg+="["+arr[0];
		for(int x=1;x<size;x++){
			erg+=","+arr[x];
		}
		erg+="]";
		return erg;
	}
	
	/**
	 * Setzt das Objekt auf seinen Ursprungs Wert zurück
	 */
	public void clear(){
		this.arr = new int[10];
		this.size=0;
	}
	
	/**
	 * Gibt die Anzahl der Elemente zurück die in der List gespeichert werden
	 * @return int length
	 */
	public int size(){
		return size;
	}
	
	/**
	 * Gibt die groesse des Arrays zurück in dem die Werte gespeichert werden
	 * @return int array groesse
	 */
	public int capacity(){
		return this.arr.length;
	}
	
	/** 
	 * Klont das Objekt
	 * @return MyArrayList 
	 */
	public MyArrayList clone(){
		MyArrayList erg=new MyArrayList();
		for(int x=0;x<this.size;x++){
			erg.add(this.arr[x]);
		}
		return erg;
	}
	
	/**
	 * Fuegt ein Element an der angegebenen stelle hinzu
	 * @param i Wert der hinzugefuegt werden soll
	 * @param pos Position an dem der Wert hinzugefuegt werden soll
	 * @throws ArrayIndexOutOfBoundException wenn pos nicht zwischen 0 und size liegt
	 */
	public void add(int i, int pos){
		int[] tmp = new int[this.arr.length];
		int y=0;
		if(pos<0 || pos >=size){
			throw new ArrayIndexOutOfBoundsException("pos liegt nicht zwischen 0 und size");
		}
		for(int x=0;x<size+1;x++){
			if(x==pos){
				tmp[x]=i;
				y=1;
			}
			tmp[x+y]=arr[x];
		}
		arr=tmp;
		size++;
		resize();
	}
	
	/**
	 * Loescht das Element an der angegebenen Stelle
	 * @param pos position der Stelle
	 * @throws ArrayIndexOutOfBoundsException wenn pos nicht zwischen 0 und size liegt
	 */
	public void delete(int pos){
		int[] tmp = new int[this.arr.length];
		int y=0;
		if(pos<0 || pos >=size){
			throw new ArrayIndexOutOfBoundsException("pos liegt nicht zwischen 0 und size");
		}
		for(int x=0;x<size-1;x++){
			if(x==pos){
				y=1;
			}
			tmp[x]=arr[x+y];
		}
		arr=tmp;
		size--;
		resize();
	}
	
	/**
	 * Aktualisiert die groesse des Arrays
	 */
	private void resize(){
		if(size==arr.length){
			int[] tmp = new int[size*2];
			for(int x=0;x<arr.length;x++){
				tmp[x]=arr[x];
			}
			arr=tmp;
		}else if(size<Math.ceil(arr.length/3.0)){
			int[] tmp = new int[arr.length/2];
			for(int x=0;x<tmp.length;x++){
				tmp[x]=arr[x];
			}
			arr=tmp;
		}
	}
}
