package de.lordgarno;

public class Test {

	public static void main(String[] args) {
		KochKurve k = new KochKurve();
		System.out.print("Rekursionstiefe 0:");
		k.kochKurve(0, 500, 500, 500, 0);
		System.out.println("(500/500)");
		
		System.out.print("Rekursionstiefe 1:");
		k.kochKurve(0, 500, 500, 500, 1);
		System.out.println("(500/500)");
		
		System.out.print("Rekursionstiefe 2:");
		k.kochKurve(0, 500, 500, 500, 2);
		System.out.println("(500/500)");
	}
}
