package de.lordgarno;

import java.text.DecimalFormat;

/**
 * Ermoeglicht einfache Rechenoperationen mit Vektoren im R2.
 * Gibt immer einen neuen Vektor zurueck und verändert nicht die inneren Werte.
 * @author nheinrichs
 *
 */
public class Vector {
	
	private double x;
	private double y;
	
	/**
	 * Konstruiert einen neuen Vektor im R2 mit den Punkten x,y
	 * @param x Wert auf der X-Achse
	 * @param y Wert auf der Y-Achse
	 */
	public Vector(double x, double y){
		this.x=x;
		this.y=y;
	}
	
	/**
	 * Erstellt einen neuen Bewegungsvektor der auf Punkt B Zeigt.
	 * @param v1 Vektor mit Punkt A
	 * @param v2 Vektor mit Punkt B
	 */
	public Vector(Vector v1, Vector v2){
		this.x=v2.x-v1.x;
		this.y=v2.y-v1.y;
	}
	
	/**
	 * Klont den Vector
	 * @param v Vector der geklont wird
	 */
	public Vector(Vector v){
		this.x=v.x;
		this.y=v.y;
	}
	
	/**
	 * Multipliziert den vector mit dem angegebenen Wert.
	 * @param d Wert der mit dem Vector multipliziert wird.
	 * @return Vector mit den multiplizierten werten
	 */
	public Vector mult(double d){
		return new Vector(x*d,y*d);
	}
	
	/**
	 * Addiert 2 Vectoren
	 * @param v Vector der auf den aktuellen Vector addiert wird
	 * @return Vector mit der Summe der beiden vectoren
	 */
	public Vector add(Vector v){
		return new Vector(x+v.x,y+v.y);
	}
	
	/**
	 * Dreht den Vector in um g Grad
	 * @param g Grad in degrees
	 * @return Vector mit den gedrehten Werten
	 */
	
	public Vector rotate(double g){
		return new Vector(x*Math.cos(Math.toRadians(g))-y*Math.sin(Math.toRadians(g)),(x*Math.sin(Math.toRadians(g)))+(y*Math.cos(Math.toRadians(g))));
	}
	
	/**
	 * Gibt das Objekt als String zurueck
	 */
	public String toString(){
		DecimalFormat format=new DecimalFormat("#0.#");
		return "("+format.format(x)+"/"+format.format(y)+")";
	}
	
	/**
	 * Gibt den X Wert des Objekts zurueck
	 * @return x
	 */
	public double getX(){
		return x;
	}
	
	/**
	 * Gibt den Y Wert des Objekt zurueck
	 * @return y
	 */
	public double getY(){
		return y;
	}
}
