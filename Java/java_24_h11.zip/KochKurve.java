package de.lordgarno;

public class KochKurve {
	
	/**
	 * Gibt rekursiv die Eckpunkte der KochKurve an.
	 * Der letzte Punkt wird nicht mit ausgegeben.
	 * @param ax Punkt A Wert auf der X-Achse
	 * @param ay Punkt A Wert auf der Y-Achse
	 * @param bx Punkt B Wert auf der X-Achse
	 * @param by Punkt B Wert auf der Y-Achse
	 * @param rek Anzahl der rekursions Tiefe
	 */
	public static void kochKurve(double ax, double ay, double bx, double by, int rek){
		--rek;
		if(rek==-1){
			System.out.print("("+ax+"/"+bx+")");
			return;
		}
		Vector a=new Vector(ax,ay);
		Vector e=new Vector(bx,by);
		Vector length=new Vector(a,e);
		length = length.mult((1.0/3));
		Vector b=new Vector(a.add(length));
		Vector c=new Vector(b.add(length.rotate(-60)));
		Vector d=new Vector(c.add(length.rotate(60)));
		if(rek==0){
			System.out.print(a.toString()+" ");
			System.out.print(b.toString()+" ");
			System.out.print(c.toString()+" ");
			System.out.print(d.toString()+"\n");
		}else{
			kochKurve(a.getX(), a.getY(), b.getX(), b.getY(), rek);
			kochKurve(b.getX(), b.getY(), c.getX(), c.getY(), rek);
			kochKurve(c.getX(), c.getY(), d.getX(), d.getY(), rek);
			kochKurve(d.getX(), d.getY(), e.getX(), e.getY(), rek);
		}
	}
}