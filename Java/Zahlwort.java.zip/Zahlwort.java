package de.lordgarno;

public class Zahlwort {

		public static String getZahlwort(int x){
			if(x<1||x>9999){
				throw new ArithmeticException("Zahl ausserhalb des Bereiches");
			}
			String[] einer ={"","eins","zwei","drei","vier","fuenf","sechs","sieben","acht","neun"};
			String[] zehner={"","zehn","zwanzig","dreissig","vierzig","fuenfzig","sechzig","siebzig","achtzig","neunzig"};
			String[] sonder={"hundert","tausend","und","ein","elf","zwoelf","siebzehn"};
			StringBuilder zahl=new StringBuilder(Integer.toString(x));
			StringBuilder erg=new StringBuilder("");
			int tmp=0;
			for(;zahl.length()!=4;){
				zahl.insert(0, '0');
			}
			tmp=zahl.charAt(0)-48;
			if(tmp!=0){
				if(tmp==1){
					erg.append(sonder[3]+sonder[1]);
				}else{
					erg.append(einer[tmp]+sonder[1]);
				}
			}
			tmp=zahl.charAt(1)-48;
			if(tmp!=0){
				if(tmp==1){
					erg.append(sonder[3]+sonder[0]);
				}else{
					erg.append(einer[tmp]+sonder[0]);
				}
			}
			tmp=Integer.parseInt(zahl.substring(2, 4));
			if(tmp!=0){
				if(tmp<10){
					erg.append(einer[tmp]);
				}else if(tmp==11){
					erg.append(sonder[4]);
				}else if(tmp==12){
					erg.append(sonder[5]);
				}else if(tmp==17){
					erg.append(sonder[6]);
				}else if(tmp<20){
					erg.append(einer[tmp%10]);
					erg.append(zehner[1]);
				}else {
					erg.append(einer[tmp%10]);
					erg.append(sonder[2]);
					erg.append(zehner[tmp/10]);
				}
			}
			return erg.toString();
		}
		
		public static Stream<String> getZahlStream(int start, int stop){
			
		}
		
		public static void main(String[] args) {
			for(int x=1;x<=9999;++x){
				System.out.println(getZahlwort(x));
			}
		}
}
