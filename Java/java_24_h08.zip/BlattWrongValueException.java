package de.lordgarno;

public class BlattWrongValueException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	/**
	 * Konstruktor
	 * @param error String der beim Fehler angezeigt wird
	 */
	public BlattWrongValueException(String error){
		super(error);
	}
}
