package de.lordgarno;

public class Blatt {
	
	private int[] blatt;
	
	/**
	 * Konstruktor 
	 * @param blatt int Array mit der goesse 3
	 */
	public Blatt(int[] blatt){
		if(blatt.length!=3){
			throw new BlattWrongValueException("Illegal size");
		}else{
			for(int x=0;x<blatt.length;++x){
				if(blatt[x]<2||blatt[x]>14){
					throw new BlattWrongValueException("Illegal card numbers");
				}
			}
		}
		this.blatt=blatt;
	}
	
	/**
	 * Wandelt das int Array in ein String um
	 * Format: "1, 2, 3"
	 */
	public String toString(){
		return blatt[0]+", "+blatt[1]+", "+blatt[2];
	}
	
	/**
	 * Gibt das Attribut blatt zurück
	 * @return int[]
	 */
	public int[] getBlatt(){
		return this.blatt;
	}
}
