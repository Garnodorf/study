package de.lordgarno;

import java.util.Comparator;

public class BlattVergleich implements Comparator<Blatt>{

	@Override
	/**
	 * Vergleicht zwei Blatt objekte.
	 * Gibt eine positive Zahl zurueck, wenn Blatt 1 mehr wert ist als Blatt 2
	 * Gibt eine negative Zahl zurueck, wenn Blatt 2 mehr wert ist als Blatt 1
	 * Gibt 0 zurueck, wenn beide Blaetter gleich viel Wert sind
	 */
	public int compare(Blatt b1, Blatt b2) {
		int pointsB1=0;
		int pointsB2=0;
		int typeB1=0;
		int typeB2=0;
		for(int x=0;x<3;++x){
			pointsB1+=b1.getBlatt()[x];
			pointsB2+=b2.getBlatt()[x];
		}
		if(b1.getBlatt()[0]==b1.getBlatt()[1]&&b1.getBlatt()[1]==b1.getBlatt()[2]){
			typeB1=2;
		}else if(b1.getBlatt()[0]==b1.getBlatt()[1]||b1.getBlatt()[0]==b1.getBlatt()[2]||b1.getBlatt()[1]==b1.getBlatt()[2]){
			typeB1=1;
		}
		
		if(b2.getBlatt()[0]==b2.getBlatt()[1]&&b2.getBlatt()[1]==b2.getBlatt()[2]){
			typeB2=2;
		}else if(b2.getBlatt()[0]==b2.getBlatt()[1]||b2.getBlatt()[0]==b2.getBlatt()[2]||b2.getBlatt()[1]==b2.getBlatt()[2]){
			typeB2=1;
		}
		
		if(typeB1==typeB2){
			return pointsB1-pointsB2;
		}else if(typeB1>typeB2){
			return 1;
		}else if(typeB1<typeB2){
			return -1;
		}
		return 0;
	}	
}
