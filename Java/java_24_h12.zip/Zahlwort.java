package de.lordgarno;

import java.util.ArrayList;
import java.util.stream.Stream;

public class Zahlwort {

	/**
	 * Wandelt ein int in einen String als ausgeschriebene Form um mit den Namen der Zahl
	 * @param x int
	 * @return String
	 */
		public static String getZahlwort(int x){
			if(x<1||x>9999){
				throw new ArithmeticException("Zahl ausserhalb des Bereiches");
			}
			String[] einer ={"","eins","zwei","drei","vier","fuenf","sechs","sieben","acht","neun"};
			String[] zehner={"","zehn","zwanzig","dreissig","vierzig","fuenfzig","sechzig","siebzig","achtzig","neunzig"};
			String[] sonder={"hundert","tausend","und","ein","elf","zwoelf","siebzehn"};
			StringBuilder zahl=new StringBuilder(Integer.toString(x));
			StringBuilder erg=new StringBuilder("");
			int tmp=0;
			for(;zahl.length()!=4;){
				zahl.insert(0, '0');
			}
			tmp=zahl.charAt(0)-48;
			if(tmp!=0){
				if(tmp==1){
					erg.append(sonder[3]+sonder[1]);
				}else{
					erg.append(einer[tmp]+sonder[1]);
				}
			}
			tmp=zahl.charAt(1)-48;
			if(tmp!=0){
				if(tmp==1){
					erg.append(sonder[3]+sonder[0]);
				}else{
					erg.append(einer[tmp]+sonder[0]);
				}
			}
			tmp=Integer.parseInt(zahl.substring(2, 4));
			if(tmp!=0){
				if(tmp<10){
					erg.append(einer[tmp]);
				}else if(tmp==11){
					erg.append(sonder[4]);
				}else if(tmp==12){
					erg.append(sonder[5]);
				}else if(tmp==17){
					erg.append(sonder[6]);
				}else if(tmp<20){
					erg.append(einer[tmp%10]);
					erg.append(zehner[1]);
				}else {
					if(tmp%10==1) {
						erg.append(sonder[3]);
					}else {
						erg.append(einer[tmp%10]);
					}
					if(tmp%10!=0) {
						erg.append(sonder[2]);
					}
					erg.append(zehner[tmp/10]);
				}
			}
			return erg.toString();
		}
		
		/**
		 * Wandelt von start bis stop inklusive alle int's in Strings als ausgeschriebene Form um und gibt diese als Stream zur�ck. 
		 * @param start start Zahl (inklusive)
		 * @param stop letzte Zahl(inklusive)
		 * @return Stream<String> aller Zahlen
		 */
		public static Stream<String> getZahlStream(int start, int stop){
			ArrayList<String> erg = new ArrayList<String>();
			for(int x=start;x<=stop;++x) {
				erg.add(getZahlwort(x));
			}
			return erg.stream();
		}
}
