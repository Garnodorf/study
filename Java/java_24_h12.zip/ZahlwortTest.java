package de.lordgarno;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;

import org.junit.Test;

public class ZahlwortTest {
	
	@Test
	public void testGetZahlwort() {
		int[] testtabelle = {1,10,11,12,16,17,20,38,69,70,131,195,2345};
		String[] result = {"eins","zehn","elf","zwoelf","sechszehn","siebzehn","zwanzig","achtunddreissig","neunundsechzig","siebzig","einhunderteinunddreissig","einhundertfuenfundneunzig","zweitausenddreihundertfuenfundvierzig"};
		for(int x=0;x<testtabelle.length;++x) {
			assertEquals("Test "+testtabelle[x]+": ", result[x], Zahlwort.getZahlwort(testtabelle[x]));
		}
	}

	@Test(expected = ArithmeticException.class)
	public void testNull() {
		Zahlwort.getZahlwort(0);
	}
	
	@Test(expected = ArithmeticException.class)
	public void testZehntausend() {
		Zahlwort.getZahlwort(10000);
	}
	
	@Test
	public void testZahlStream() {
		String[] result = {"acht","neun","zehn","elf","zwoelf"};
		Object[] erg = Zahlwort.getZahlStream(8, 12).toArray();
		for(int x=0;x<erg.length;++x) {
			assertEquals("Test "+result[x]+": ", result[x], erg[x]);
		}
	}
}
