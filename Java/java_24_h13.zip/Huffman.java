package de.lordgarno;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Huffman {
	/**
	 * Entschluesselt einen Text der vorher durch die Huffman-Codierung verschluesselt wurde.
	 * @param f File verschluesselte Datei
	 * @return entschluesselter String
	 */
	public static String decode(File f){
		StringBuilder erg=new StringBuilder();
		try {
			ArrayList<String> al = new ArrayList<>();
			BufferedReader br = new BufferedReader(new FileReader(f));
			String tmp;
			String main;
			int start=0;
			for(;(tmp=br.readLine())!=null;){
				al.add(tmp);
			}
			if(al.size()!=28){
				throw new IllegalArgumentException();
			}
			main=al.get(0);
			for(int x=1;x<main.length()+1;++x){
				for(int y=1;y<28;++y){
					if(al.get(y).equals(main.substring(start, x))){
						if(y==27){
							erg.append(" ");
						}else{
							erg.append((char)(y+64));
						}
						start=x;
						break;
					}
				}
			}
		} catch (FileNotFoundException e) {
			System.out.println("Die Datei konnte nicht gefunden werden!");
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return erg.toString();
	}
	
	/**
	 * Test Main zum Testen
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println(decode(new File("/home/nheinrichs/localstorage/workspace/ha13/src/de/lordgarno/test.txt")));
	}
}
