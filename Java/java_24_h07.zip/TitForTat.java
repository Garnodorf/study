package de.lordgarno;

public class TitForTat implements GefStrategie{

	private boolean enemyDecision;
	private boolean isFirstRound;
	
	/**
	 * Konstruktor
	 */
	public TitForTat(){
		isFirstRound=true;
	}
	
	/**
	 * Kooperiert in der ersten Runde und kopiert in den nächsten Runden den vorherigen Spielzug des Spielpartners 
	 */
	@Override
	public boolean getNextDecision() {
		if(isFirstRound){
			isFirstRound=false;
			return true;
		}
		return enemyDecision;
	}

	@Override
	public void setOpponentsLastDecision(boolean decision) {
		enemyDecision = decision;
	}

}
