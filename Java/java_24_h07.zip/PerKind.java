package de.lordgarno;

public class PerKind implements GefStrategie{

	private int step;
	
	public PerKind(){
		step=0;
	}
	
	@Override
	public boolean getNextDecision() {
		if(step==0){
			++step;
			return true;
		}else if(step==1){
			++step;
			return true;
		}else {
			step=0;
			return false;
		}
	}

	@Override
	public void setOpponentsLastDecision(boolean decision) {}

}
