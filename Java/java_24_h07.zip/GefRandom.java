package de.lordgarno;

import java.util.Random;

public class GefRandom implements GefStrategie{
	
	private Random random;
	
	public GefRandom(){
		random=new Random();
	}
	
	@Override
	public boolean getNextDecision() {
		if(random.nextInt(2)==1){
			return true;
		}else{
			return false;
		}
	}

	@Override
	public void setOpponentsLastDecision(boolean decision) {}

}
