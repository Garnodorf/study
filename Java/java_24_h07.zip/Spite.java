package de.lordgarno;

public class Spite implements GefStrategie{

	private boolean enemyDecision;
	private boolean isHateTurnedOn;
	
	/**
	 * Konstruktor
	 */
	public Spite(){
		isHateTurnedOn = false;
	}
	
	/**
	 * Kooperiert solange, bis der Mitspieler zum ersten Mal verrät. Verrät danach immer.
	 */
	@Override
	public boolean getNextDecision() {
		if(enemyDecision==false){
			isHateTurnedOn=true;
		}
		if(isHateTurnedOn){
			return false;
		}else{
			return true;
		}
	}

	@Override
	public void setOpponentsLastDecision(boolean decision) {
		enemyDecision = decision;
	}

}
