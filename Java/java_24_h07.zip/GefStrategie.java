package de.lordgarno;

public interface GefStrategie {
	
	/**
	 * Entscheided sich für entweder für kooperieren oder betrügen
	 * @return boolean Entscheidung
	 */
	public boolean getNextDecision();
	
	/**
	 * Speichert die Entscheidung des Gegners in der vorrunde
	 * @param decision Entscheidung des Gegners
	 */
	public void setOpponentsLastDecision(boolean decision);
}
