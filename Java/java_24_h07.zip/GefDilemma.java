package de.lordgarno;

public class GefDilemma {

	private GefStrategie playerOne;
	private int playerOnePoints;
	private GefStrategie playerTwo;
	private int playerTwoPoints;
	
	/**
	 * Konstruktor
	 * @param s1 GefStrategie Strategie für Spieler 1
	 * @param s2 GefStrategie Strategie für Spieler 2
	 */
	public GefDilemma(GefStrategie s1,GefStrategie s2){
		this.playerOne=s1;
		this.playerTwo=s2;
	}
	
	/**
	 * Startet das Spiel und Spielt n spiele
	 * @param n 
	 */
	public void spiele(int n){
		boolean playerOneDecision;
		boolean playerTwoDecision;
		playerOnePoints=0;
		playerTwoPoints=0;
		for(int x=0;x<n;x++){
			playerOneDecision=playerOne.getNextDecision();
			playerTwoDecision=playerTwo.getNextDecision();
			setPoints(playerOneDecision, playerTwoDecision);
			playerOne.setOpponentsLastDecision(playerTwoDecision);
			playerTwo.setOpponentsLastDecision(playerOneDecision);
		}
		printPoints();
	}
	
	/**
	 * Ueberpueft die Aussagen der beiden Spieler und verteilt dem entsprechend Punkte
	 * @param pOneDecision Entscheidung des ersten Spielers
	 * @param pTwoDecision Entscheidung des zweiten Spielers
	 */
	private void setPoints(boolean pOneDecision, boolean pTwoDecision){
		if(pOneDecision==true && pTwoDecision==true){
			playerOnePoints += 2;
			playerTwoPoints += 2;
		}else if(pOneDecision == false && pTwoDecision == false){
			playerOnePoints += 4;
			playerTwoPoints += 4;
		}else if(pOneDecision == true && pTwoDecision == false){
			playerOnePoints += 6;
			playerTwoPoints += 1;
		}else if(pOneDecision == false && pTwoDecision == true){
			playerOnePoints += 1;
			playerTwoPoints += 6;
		}
	}
	
	/**
	 * Gibt den aktuellen Punktestand in der Konsole aus.
	 */
	private void printPoints(){
		if(playerOnePoints>playerTwoPoints){
			System.out.println("Punktestand: Spieler2 liegt vorne. Player1 "+playerOnePoints+"|"+playerTwoPoints+" Player2");
		}else if(playerOnePoints<playerTwoPoints){
			System.out.println("Punktestand: Spieler1 liegt vorne. Player1 "+playerOnePoints+"|"+playerTwoPoints+" Player2");
		}else if(playerOnePoints==playerTwoPoints){
			System.out.println("Punktestand: Gleichstand mit jeweils "+playerOnePoints+" Punkten.");
		}
	}
}
