package de.lordgarno;

public class Pavlov implements GefStrategie{

	private boolean enemyDecision;
	private boolean isFirstRound;
	private boolean lastDecision;
	
	/**
	 * Konstruktor
	 */
	public Pavlov(){
		isFirstRound = true;
	}
	
	/**
	 * Kooperiert in der ersten Runde und verrät, falls der vorherige Zug des Mitspielers anders als der eigene war.
	 */
	@Override
	public boolean getNextDecision() {
		if(isFirstRound){
			isFirstRound = false;
			lastDecision=true;
		}else if(lastDecision==enemyDecision){
			lastDecision=true;
		}else{
			lastDecision=false;
		}
		return lastDecision;
	}

	@Override
	public void setOpponentsLastDecision(boolean decision) {
		enemyDecision = decision;
	}

}
