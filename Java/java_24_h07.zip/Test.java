package de.lordgarno;

public class Test {

	/**
	 * Test klasse zum testen des Gefangenendilemmas
	 * @param args
	 */
	public static void main(String[] args) {
		//Neues Objekt vom Typ GefDilemma mit 2 Spielern
		GefDilemma gd = new GefDilemma(new TitForTat(),new Pavlov());
		//100 mal spielen
		gd.spiele(100);
	}

}
